#!/bin/sh
# Commands that produced the runs in data/ (E_J = E_C/2, kappa = 1/2; wall times on one core in README.md).
set -e
cd "$(dirname "$0")/src"
python3 two_islands.py hull
python3 two_islands.py duality
python3 staircase.py
python3 two_islands.py relax 2   --beta 2        # locking from (2,0)            -> data/pair_relax_q2.0_J0.5_b2.0.npz
python3 two_islands.py relax 2.5 --beta 2        # moving minimum at q = 2.5     -> data/pair_relax_q2.5_J0.5_b2.0.npz
python3 two_islands.py relax 2   --beta 1        # trapping near thermal saddles -> data/pair_relax_q2.0_J0.5_b1.0.npz
python3 two_islands.py leak 0.00025 --beta 4     # slow leak                     -> data/pair_leak_0.00025_J0.5_b4.0.npz
python3 two_islands.py leak 0.00025 --beta 2     #                               -> data/pair_leak_0.00025_J0.5_b2.0.npz
python3 two_islands.py leak 0.0005  --beta 2     #                               -> data/pair_leak_0.0005_J0.5_b2.0.npz
python3 two_islands.py leak 0.002   --beta 2     #                               -> data/pair_leak_0.002_J0.5_b2.0.npz
python3 diagnostics.py
python3 make_figures.py
