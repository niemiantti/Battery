#!/usr/bin/env python3
"""
Spectral structure of the two-island pair (data for Fig. 1 and for the thermal-segment discussion).

  * Lagrange-dual staircases W_Q(q) = E_min(q) - E_G on Gibbs orbits (beta*Ec = 1, 2, 4; ladder |m_i| <= 5)
    and on the pure orbit (T = 0, from the exact sector ground energies), for E_J = 0 and E_J = Ec/2.
  * The parity splitting delta_J(E_J) from the exact sector ground energies, compared with its
    second-order expansion E_J/2 - 3 E_J^2 / (16 Ec).
  * The slopes of the finite-temperature staircase on [0, 2] (plateaus and thermal segments).

Writes ../data/pair_staircase.npz.   Runtime: a few minutes.
"""
import argparse
from pathlib import Path
import numpy as np
from two_islands import Pair, Ec, DATA


def dual_curve(P, qs, spec, mus):
    return np.array([P.Emin_dual(q, spec, mus) for q in qs])


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', type=Path, default=DATA); args = ap.parse_args()
    out = {}
    # --- parity splitting versus E_J (exact sectors, |m_i| <= 7)
    EJs = np.linspace(0, 3.0, 61); dJ = []
    for EJ in EJs:
        P = Pair(7, EJ, None); e0, e1 = P.sector_ground(0), P.sector_ground(1)
        dJ.append(0.5 * Ec - (e1 - e0 - 0.5 * Ec))
    out['EJs'] = EJs; out['dJ'] = np.array(dJ)
    print("delta_J(E_J):  E_J   exact    E_J/2 - 3E_J^2/16")
    for e in (0.1, 0.25, 0.5, 1.0):
        k = np.argmin(np.abs(EJs - e)); print(f"               {e:<5} {dJ[k]:.4f}   {e / 2 - 3 * e ** 2 / 16:.4f}")
    # --- staircases
    qs = np.linspace(0, 4, 801); mus = np.linspace(-1, 9, 40001); out['q'] = qs
    for EJ in (0.0, 0.5):
        P0 = Pair(6, EJ, None); Qv = np.arange(-6, 13); E0 = np.array([P0.sector_ground(Q) for Q in Qv])
        W0 = np.array([np.max(np.min(E0[None, :] - mus[:, None] * Qv[None, :], axis=1) + mus * q) for q in qs]) - E0.min()
        out[f'W_T0_J{EJ}'] = W0
        for beta in (1.0, 2.0, 4.0):
            P = Pair(5, EJ, beta); W = dual_curve(P, qs, P.spec, mus) - P.EG; out[f'W_b{beta}_J{EJ}'] = W
            print(f"E_J={EJ} beta*Ec={beta}: W_Q(1)={W[200]:.4f} W_Q(2)={W[400]:.4f} W_Q(3)={W[600]:.4f} W_Q(4)={W[800]:.4f}   "
                  f"recurrence |W(q+2)-W(q)-2Ec(q+1)|max = {np.max(np.abs(W[400:] - W[:401] - 2 * Ec * (qs[:401] + 1))):.1e}")
        print(f"E_J={EJ} T=0:        W_Q(1)={W0[200]:.4f} W_Q(2)={W0[400]:.4f} W_Q(3)={W0[600]:.4f}")
    np.savez(args.data / 'pair_staircase.npz', **out); print("saved", args.data / 'pair_staircase.npz')
    # --- slopes on [0,2]: plateaus and thermal segments
    print("\nslopes of W_Q on [0,2] (segments of constant slope longer than 0.012 in q):")
    qf = np.linspace(0, 2, 401); muf = np.linspace(-1, 5, 60001)
    for beta in (1.0, 2.0, 4.0):
        for EJ in (0.0, 0.5):
            P = Pair(5, EJ, beta); E = dual_curve(P, qf, P.spec, muf) - P.EG; sl = np.diff(E) / (qf[1] - qf[0])
            segs = []; start = 0
            for i in range(1, len(sl)):
                if abs(sl[i] - sl[i - 1]) > 2e-3: segs.append((qf[start], qf[i], sl[start:i].mean())); start = i
            segs.append((qf[start], qf[-1], sl[start:].mean()))
            print(f"  beta*Ec={beta} E_J={EJ}: " + "; ".join(f"[{a:.3f},{b:.3f}] {s:.4f}" for a, b, s in segs if b - a > 0.012))


if __name__ == '__main__':
    main()
