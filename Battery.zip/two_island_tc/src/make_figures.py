#!/usr/bin/env python3
"""Figures of the paper from the saved runs in ../data (writes ../figures/fig1_pair.{pdf,png}, fig2_pair.{pdf,png}).
Usage: python make_figures.py [--data DIR] [--figures DIR]"""
import numpy as np, os, glob, argparse
from pathlib import Path
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 7.5, 'axes.labelsize': 7.5, 'legend.fontsize': 6.2, 'axes.titlesize': 7.5,
                     'lines.linewidth': 1.1, 'axes.linewidth': 0.5, 'xtick.major.width': 0.5, 'ytick.major.width': 0.5,
                     'xtick.labelsize': 7, 'ytick.labelsize': 7, 'pdf.fonttype': 42, 'mathtext.fontset': 'cm'})
ap = argparse.ArgumentParser(); ap.add_argument('--data', type=Path, default=Path(__file__).resolve().parents[1] / 'data')
ap.add_argument('--figures', type=Path, default=Path(__file__).resolve().parents[1] / 'figures'); args = ap.parse_args(); args.figures.mkdir(parents=True, exist_ok=True)
DATA, FIGS = str(args.data), args.figures
C = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948']
Ec = 1.0
def save(fig, name):
    fig.savefig(FIGS / f'{name}.pdf'); fig.savefig(FIGS / f'{name}.png', dpi=220); print(FIGS / f'{name}.pdf', 'written')
def cum(y, x): return np.concatenate([[0.0], np.cumsum(0.5 * (y[1:] + y[:-1]) * np.diff(x))])

# ------------------------------------------------------------ Fig. 1: staircase, slopes, splitting
D = np.load(f'{DATA}/pair_staircase.npz'); q = D['q']
fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.25))
curves = [('W_T0_J0.5', '$T=0$', C[0]), ('W_b4.0_J0.5', r'$\beta E_{\rm C}=4$', C[1]), ('W_b2.0_J0.5', r'$\beta E_{\rm C}=2$', C[2]), ('W_b1.0_J0.5', r'$\beta E_{\rm C}=1$', C[3])]
for key, lab, c in curves:
    ax[0].plot(q, D[key] - Ec * q**2 / 2, color=c, label=lab)
ax[0].plot(q, D['W_T0_J0.0'] - Ec * q**2 / 2, color='k', ls=':', lw=0.8, label=r'$T=0$, $E_J=0$')
ax[0].axhline(0, color='k', lw=0.5)
ax[0].set_xlabel(r'total charge $q$'); ax[0].set_ylabel(r'$[\mathcal{W}_Q(q)-E_{\rm C}q^2/2]/E_{\rm C}$'); ax[0].legend(frameon=False, handlelength=1.5, ncol=2, columnspacing=0.8, loc='upper center')
ax[0].set_ylim(-0.02, 0.76); ax[0].set_title('(a)', loc='left')
for key, lab, c in curves[:1] + curves[2:]:
    W = D[key]; sl = np.gradient(W, q); ax[1].plot(q, sl, color=c, label=lab, lw=1.0)
ax[1].plot(q, Ec * q, 'k--', lw=0.7, label=r'classical $E_{\rm C}q$')
for k in range(2):
    for s in (-1, 1): ax[1].axhline(Ec * (2 * k + 1) + s * 0.2038, color='k', ls=':', lw=0.5)
ax[1].set_xlabel(r'total charge $q$'); ax[1].set_ylabel(r'$\mu=\partial\mathcal{W}_Q/\partial q$  ($E_{\rm C}$)'); ax[1].set_xlim(0, 4); ax[1].set_ylim(0, 4.2)
ax[1].legend(frameon=False, handlelength=1.5, loc='upper left'); ax[1].set_title('(b)', loc='left')
EJs, dJ = D['EJs'], D['dJ']
ax[2].plot(EJs, dJ, color=C[0], label=r'$\delta_J$ (exact)'); m = EJs <= 1.2; ax[2].plot(EJs[m], EJs[m] / 2 - 3 * EJs[m]**2 / 16, color=C[1], ls='--', label=r'$E_J/2-3E_J^2/16E_{\rm C}$')
ax[2].axhline(0.5, color='k', ls=':', lw=0.6); ax[2].set_xlim(0, 3); ax[2].set_ylim(0, 0.55)
ax[2].set_xlabel(r'$E_J/E_{\rm C}$'); ax[2].set_ylabel(r'$\delta_J/E_{\rm C}$'); ax[2].legend(frameon=False, handlelength=1.5, loc='lower right'); ax[2].set_title('(c)', loc='left')
fig.tight_layout(w_pad=0.9); save(fig, 'fig1_pair')

# ------------------------------------------------------------ Fig. 2: dynamics
fig, ax = plt.subplots(1, 4, figsize=(7.0, 1.95))
fr = sorted(glob.glob(f'{DATA}/pair_relax_q2.0_J0.5_b*.npz'))
if fr:
    R = np.load(fr[-1]); A = R['R']; t = A[:, 0].real; N1, N2, E = A[:, 1].real, A[:, 2].real, A[:, 3].real; X = A[:, 5]; EG = float(R['EG']); Emin = float(R['Emin'])
    ax[0].plot(t, N1 - N2, color=C[0], label=r'$\Delta N=\langle N_1\rangle-\langle N_2\rangle$')
    ax[0].plot(t, 4 * X.imag, color=C[1], lw=0.8, label=r'$4\langle\sin\theta\rangle$')
    ax[0].plot(t, E - Emin, color=C[2], label=r'$(E-E_{\min})/E_{\rm C}$')
    ax[0].set_xlim(0, 100); ax[0].set_xlabel(r'$t\,E_{\rm C}/\hbar$'); ax[0].legend(frameon=False, handlelength=1.3); ax[0].set_title('(a)', loc='left')
    ph = np.unwrap(np.angle(X)); om = np.gradient(ph, t)
    ax[1].plot(t, om, color=C[1], lw=0.8, label=r'$\dot{\arg}\langle e^{i\theta}\rangle$'); ax[1].plot(t, 2 * Ec * (N1 - N2), color=C[0], ls='--', lw=0.8, label=r'$2E_{\rm C}\Delta N/\hbar$')
    ax[1].set_xlim(0, 100); ax[1].set_ylim(-0.6, 4.8); ax[1].set_xlabel(r'$t\,E_{\rm C}/\hbar$'); ax[1].set_ylabel(r'frequency ($E_{\rm C}/\hbar$)')
f25 = sorted(glob.glob(f'{DATA}/pair_relax_q2.5_J0.5_b*.npz'))
if f25:
    R = np.load(f25[-1]); A = R['R']; t = A[:, 0].real; T1 = A[:, 6]; mu = A[:, 4].real
    phT = np.unwrap(np.angle(T1)); omT = np.gradient(phT, t)
    ax[1].plot(t, omT, color=C[2], lw=0.8, label=r'$\dot{\arg}\langle T_1\rangle$'); ax[1].plot(t, mu, color='k', ls=':', lw=0.8, label=r'$\mu(t)/\hbar$')
ax[1].legend(frameon=False, handlelength=1.3, fontsize=5.8, loc='center right', bbox_to_anchor=(1.0, 0.46), ncol=2, columnspacing=0.8); ax[1].set_title('(b)', loc='left')
leaks = [(f'{DATA}/pair_leak_0.00025_J0.5_b4.0.npz', r'$\beta E_{\rm C}=4$', C[0], 1.0), (f'{DATA}/pair_leak_0.00025_J0.5_b2.0.npz', r'$\beta E_{\rm C}=2$', C[1], 0.7)]
qs = np.linspace(0, 2.6, 600); st = np.where(np.floor(qs) % 2 == 0, Ec * (2 * np.floor(qs / 2) + 1) - 0.2038, Ec * (2 * np.floor(qs / 2) + 1) + 0.2038)
for fn, lab, c, lw in leaks:
    if not os.path.exists(fn): continue
    L = np.load(fn); A = L['R']; t, qq, N1, E, mu, diss, Xa, T1a = A.T
    ax[2].plot(qq, mu, color=c, lw=lw, label=lab)
    if c == C[0]:
        ax[3].plot(qq, E[0] - E, color=C[0], label='released'); ax[3].plot(qq, -cum(mu * np.gradient(qq, t), t), color=C[2], ls=':', lw=1.4, label=r'$R_Q(t)$')
        ax[3].plot(qq, cum(diss, t), color=C[3], label=r'$L(t)$, $\beta E_{\rm C}=4$')
    else:
        ax[3].plot(qq, cum(diss, t), color=C[3], ls=':', lw=1.4, label=r'$L(t)$, $\beta E_{\rm C}=2$')
for k in range(2):
    ax[2].hlines(Ec * (2 * k + 1) - 0.2038, 2 * k, 2 * k + 1, colors='k', linestyles=':', lw=1.0, label=(r'$E_{\rm C}(2k+1)\mp\delta_J$' if k == 0 else None))
    ax[2].hlines(Ec * (2 * k + 1) + 0.2038, 2 * k + 1, min(2 * k + 2, 2.6), colors='k', linestyles=':', lw=1.0)
ax[2].plot(qs, Ec * qs, color=C[2], ls='--', lw=0.9, label=r'$E_{\rm C}q$')
ax[2].set_xlim(0, 2.6); ax[2].set_ylim(0, 3.6); ax[2].set_xlabel(r'$q(t)$'); ax[2].set_ylabel(r'$\mu$  ($E_{\rm C}$)'); ax[2].legend(frameon=False, handlelength=1.3, loc='upper left', fontsize=5.6); ax[2].set_title('(c)', loc='left')
ax[3].set_xlim(0, 2.6); ax[3].set_ylim(0, 6.4); ax[3].invert_xaxis(); ax[3].set_xlabel(r'$q(t)$'); ax[3].set_ylabel(r'energy ($E_{\rm C}$)'); ax[3].legend(frameon=False, handlelength=2.2, loc='upper left', fontsize=5.8, ncol=1, labelspacing=0.35); ax[3].set_title('(d)', loc='left')
fig.tight_layout(w_pad=0.6); save(fig, 'fig2_pair')
