#!/usr/bin/env python3
"""
Two Josephson-coupled charge islands with conserved total charge, relaxed by the
covariant quantum Landau-Lifshitz-Gilbert (qLLG) flow at fixed mean charge.

Model (hbar = E_C = 1 throughout):

    H = E_C (N_1^2 + N_2^2) - E_J cos(phi_1 - phi_2),      Q = N_1 + N_2,
    e^{i(phi_1 - phi_2)} = T_1 T_2^+ ,  T_i |m>_i = |m+1>_i   (moves one charge from island 2 to 1).

The density matrix lives on the truncated ladder |m_1|, |m_2| <= M (dimension (2M+1)^2) and is
propagated in the laboratory frame,

    d rho/dt = Y - i mu [Q, rho],        i Y = [H - mu Q + kappa Y, rho],

with the covariant velocity Y obtained in the instantaneous eigenbasis of rho (see the
supplemental material of the paper, Sec. S2).  The multiplier mu (written as lam = -mu in the
code) is eliminated at every step through the affine relation  d<Q>/dt = a + lam*b:
    fixed charge      lam = -a/b
    prescribed leak   lam = -(a + gamma)/b           (d<Q>/dt = -gamma)

Sub-commands
------------
  hull     T = 0 lower convex hull of the sector ground energies and the parity splitting delta_J
  duality  E_min(q) on a Gibbs orbit by Lagrange duality; check of the two-unit recurrence
  relax    covariant relaxation at fixed total charge (locking from (q,0), moving minimum at fractional q)
  leak     prescribed slow leak of the total charge from q = 2.5

Results are written to ../data/ relative to this file (override with --data).
Run  python two_islands.py <sub-command> -h  for the parameters.
"""
import argparse, time
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm, eigh

Ec = 1.0
kappa = 0.5
DATA = Path(__file__).resolve().parents[1] / 'data'


class Pair:
    """Operators, Hamiltonian, Gibbs state and the covariant qLLG kernel on the truncated ladder."""

    def __init__(self, M, EJ, beta):
        self.M, self.EJ, self.beta = M, EJ, beta
        m = np.arange(-M, M + 1); L = len(m); self.L = L; self.d = L * L
        I = np.eye(L); T = np.diag(np.ones(L - 1), -1)                       # T|m> = |m+1>
        self.N1 = np.kron(np.diag(m), I).astype(complex); self.N2 = np.kron(I, np.diag(m)).astype(complex)
        self.T1 = np.kron(T, I).astype(complex); self.T2 = np.kron(I, T).astype(complex)
        self.Q = self.N1 + self.N2; self.n = (self.N1 - self.N2) / 2
        self.X = self.T1 @ self.T2.conj().T                                    # e^{i theta}
        self.H = Ec * (self.N1 @ self.N1 + self.N2 @ self.N2) - 0.5 * EJ * (self.X + self.X.conj().T)
        self.E, self.V = eigh(self.H)
        self.q_of_eig = np.real(np.einsum('ij,ij->j', self.V.conj(), self.Q @ self.V))
        if beta is not None:
            w = np.exp(-beta * (self.E - self.E.min())); w /= w.sum(); self.w = w
            self.rG = (self.V * w) @ self.V.conj().T; self.EG = float(np.sum(w * self.E)); self.spec = np.sort(w)

    # --- helpers -----------------------------------------------------------------------------
    def ex(self, r, O): return np.trace(r @ O)
    def pack(self, r): return np.concatenate([r.real.ravel(), r.imag.ravel()])
    def unpack(self, y): d = self.d; return (y[:d * d] + 1j * y[d * d:]).reshape(d, d)

    def core(self, rho):
        """Laboratory-frame velocity  rhodot = U (A + lam*Bm) U^+  and the coefficients of
        d<Q>/dt = a + lam*b, all in the instantaneous eigenbasis of rho (mobility M = -b >= 0)."""
        p, U = np.linalg.eigh(rho); Hb = U.conj().T @ self.H @ U; Qb = U.conj().T @ self.Q @ U
        D = p[None, :] - p[:, None]; den = 1j - kappa * D
        A = D * Hb / den; Bm = -1j * kappa * D ** 2 * Qb / den
        return U, A, Bm, np.sum(A * Qb.T), np.sum(Bm * Qb.T)

    def sector_ground(self, Qv):
        """Ground energy of the total-charge sector Q = Qv (exact block diagonalization)."""
        qd = np.real(np.diag(self.Q)); idx = np.where(np.abs(qd - Qv) < 1e-9)[0]
        return eigh(self.H[np.ix_(idx, idx)], eigvals_only=True).min()

    def Emin_dual(self, q, spec, mus=np.linspace(-1, 8, 9001)):
        """E_min(q) = max_mu [ E_passive(H - mu Q; spec) + mu q ]  (Lagrange duality)."""
        eps = self.E[None, :] - mus[:, None] * self.q_of_eig[None, :]
        Ep = np.sort(eps, axis=1) @ spec[::-1]
        return np.max(Ep + mus * q)


def trapz(y, x): return np.sum(0.5 * (y[1:] + y[:-1]) * np.diff(x))


def relax_rhs(P):
    """Fixed-charge covariant flow: the multiplier enforces d<Q>/dt = 0."""
    def rhs(t, y):
        rho = P.unpack(y); U, A, Bm, a, b = P.core(rho); lam = (-a / b).real if abs(b) > 1e-14 else 0.0
        rhs.lam = lam; return P.pack(U @ (A + lam * Bm) @ U.conj().T)
    return rhs


def prepare(P, q0, t_charge=150.0, t_relax=0.0, Ex=0.3):
    """All charge on island 1 at integer charge n = floor(q0) (exact boost T_1^n rho_G T_1^-n).
    A fractional remainder is injected by the prescribed-rate flow while island 1 is weakly coupled to an
    external phase reference, H -> H - Ex cos(phi_1), which supplies the inter-sector coherence that a
    charge-diagonal state lacks; the coupling is then removed and the state relaxed at fixed charge."""
    n = int(np.floor(q0 + 1e-9)); s = q0 - n
    rho = np.linalg.matrix_power(P.T1, n) @ P.rG @ np.linalg.matrix_power(P.T1, n).conj().T
    if s > 1e-9:
        Hsave = P.H.copy(); P.H = Hsave - 0.5 * Ex * (P.T1 + P.T1.conj().T); gamma = -s / (0.5 * t_charge)

        def f(t, y):
            r = P.unpack(y); U, A, Bm, a, b = P.core(r); lam = (-(a + gamma) / b).real if abs(b) > 1e-12 else 0.0
            return P.pack(U @ (A + lam * Bm) @ U.conj().T)

        def reached(t, y): return P.ex(P.unpack(y), P.Q).real - q0
        reached.terminal = True; reached.direction = 1
        sol = solve_ivp(f, (0, 4 * t_charge), P.pack(rho), method='DOP853', rtol=1e-8, atol=1e-10, events=reached)
        rho = P.unpack(sol.y[:, -1]); P.H = Hsave
        print(f"   (prepare: reached q={P.ex(rho, P.Q).real:.4f} at t={sol.t[-1]:.1f} with Ex={Ex})", flush=True)
    if t_relax > 0:
        sol = solve_ivp(relax_rhs(P), (0, t_relax), P.pack(rho), method='DOP853', rtol=1e-8, atol=1e-10)
        rho = P.unpack(sol.y[:, -1])
    return rho


# ============================================================================================ modes
def mode_hull(args):
    M = args.M
    print("T=0: sector ground energies, slopes of the lower convex hull and the parity splitting delta_J (units of Ec)")
    print("  EJ     E0(0)      E0(1)-Ec/2  slopes [0,1] [1,2] [2,3] [3,4]      delta_J   EJ/2-3EJ^2/16")
    for EJ in args.EJ:
        P = Pair(M, EJ, None); E0 = {Qv: P.sector_ground(Qv) for Qv in range(0, 5)}
        s = [E0[k + 1] - E0[k] for k in range(4)]; dJ = 0.5 * Ec - (E0[1] - E0[0] - 0.5 * Ec)
        print(f"  {EJ:<5.2f}  {E0[0]:+.5f}   {E0[1]-0.5:+.5f}   {s[0]:.4f} {s[1]:.4f} {s[2]:.4f} {s[3]:.4f}   {dJ:.4f}   {EJ/2-3*EJ**2/16:.4f}")


def mode_duality(args):
    print("Gibbs orbit: W_Q(q) = E_min(q) - E_G by Lagrange duality and the two-unit recurrence E_min(q+2) - E_min(q) - 2Ec(q+1)")
    qs = np.arange(0, 4.001, 0.25)
    for beta in args.beta:
        for EJ in args.EJ:
            for M in args.M:
                P = Pair(M, EJ, beta); Ed = np.array([P.Emin_dual(q, P.spec) for q in qs]) - P.EG
                rec = [Ed[i + 8] - Ed[i] - 2 * Ec * (qs[i] + 1) for i in range(len(qs) - 8)]
                print(f"  beta={beta} EJ={EJ} M={M}: E_G={P.EG:.4f}  W_Q at q=0,0.5,...,4: " + " ".join(f"{e:.3f}" for e in Ed[::2])
                      + f"   max|recurrence|={np.max(np.abs(rec)):.1e}")
                np.savez(args.data / f'pair_dual_b{beta}_J{EJ}_M{M}.npz', q=qs, W=Ed, EG=P.EG)


def mode_relax(args):
    q0, EJ, beta, M, T = args.q0, args.EJ, args.beta, args.M, args.T
    P = Pair(M, EJ, beta); rho0 = prepare(P, q0, Ex=args.Ex)
    Emin = P.Emin_dual(P.ex(rho0, P.Q).real, P.spec)
    print(f"two islands M={M} (d={P.d}), EJ={EJ}, beta*Ec={beta}: initial <N1>={P.ex(rho0, P.N1).real:.4f} <N2>={P.ex(rho0, P.N2).real:.4f} "
          f"E-E_G={P.ex(rho0, P.H).real - P.EG:.4f}; E_min-E_G={Emin - P.EG:.4f} (W_free={P.ex(rho0, P.H).real - Emin:.4f})")
    rhs = relax_rhs(P); td = min(40.0, T); ts = np.unique(np.concatenate([np.linspace(0, td, 2001), np.linspace(td, T, 721)])); t0 = time.time()
    sol = solve_ivp(rhs, (0, T), P.pack(rho0), method='DOP853', rtol=1e-8, atol=1e-10, t_eval=ts)
    rows = []
    for k in range(len(ts)):
        r = P.unpack(sol.y[:, k]); rhs(ts[k], sol.y[:, k]); lam = rhs.lam
        U, A, Bm, a, b = P.core(r); rd = U @ (A + lam * Bm) @ U.conj().T; Y = rd - 1j * lam * (P.Q @ r - r @ P.Q)
        K = P.H + lam * P.Q
        rows.append((ts[k], P.ex(r, P.N1).real, P.ex(r, P.N2).real, P.ex(r, P.H).real, -lam, P.ex(r, P.X), P.ex(r, P.T1), P.ex(r, P.T2),
                     np.linalg.norm(Y), np.linalg.norm(K @ r - r @ K), np.max(np.abs(np.sort(np.linalg.eigvalsh(r)) - P.spec))))
    R = np.array(rows, dtype=complex); t, N1, N2, E, mu, X, T1, T2, Yn, comm, sdr = R.T
    print(f"  wall {time.time() - t0:.0f}s; end: <N1>={N1[-1].real:.4f} <N2>={N2[-1].real:.4f} E-E_G={E[-1].real - P.EG:.4f} "
          f"(E_min-E_G={Emin - P.EG:.4f}) mu={mu[-1].real:+.5f} |<e^(i theta)>|={abs(X[-1]):.4f} arg={np.angle(X[-1]):+.3f} "
          f"|<T1>|={abs(T1[-1]):.4f} |<T2>|={abs(T2[-1]):.4f} ||Y||={Yn[-1].real:.1e} ||[K,rho]||={comm[-1].real:.1e} spectral drift={np.max(sdr.real):.1e}")
    ph = np.unwrap(np.angle(X)); phT = np.unwrap(np.angle(T1))
    for tt in (0, 5, 10, 20, 40, 80, 160, T):
        k = min(np.searchsorted(t.real, tt), len(t) - 2)
        print(f"   t={t[k].real:6.1f}: N1-N2={N1[k].real - N2[k].real:+.4f}  d(arg<e^(i theta)>)/dt={(ph[k + 1] - ph[k]) / (t[k + 1] - t[k]).real:+.4f} "
              f"(2Ec(N1-N2)={2 * Ec * (N1[k].real - N2[k].real):+.4f})  d(arg<T1>)/dt={(phT[k + 1] - phT[k]) / (t[k + 1] - t[k]).real:+.4f}  "
              f"mu={mu[k].real:+.4f}  |<e^(i theta)>|={abs(X[k]):.4f}  E-E_G={E[k].real - P.EG:.4f}")
    out = args.data / f'pair_relax_q{q0}_J{EJ}_b{beta}.npz'
    np.savez(out, R=R, EG=P.EG, Emin=Emin); print("  saved", out)
    print("  columns of R: t, <N1>, <N2>, E, mu, <e^(i theta)>, <T1>, <T2>, ||Y||, ||[K,rho]||, spectral drift")


def mode_leak(args):
    gamma, EJ, beta, M = args.gamma, args.EJ, args.beta, args.M
    P = Pair(M, EJ, beta); rho0 = prepare(P, args.q0, t_charge=150.0, t_relax=300.0, Ex=args.Ex)
    q0 = P.ex(rho0, P.Q).real; E0 = P.ex(rho0, P.H).real
    print(f"prepared two-island time crystal (M={M}, EJ={EJ}, beta*Ec={beta}): q={q0:.4f} (<N1>={P.ex(rho0, P.N1).real:.3f}), "
          f"E-E_G={E0 - P.EG:.4f}, E_min-E_G={P.Emin_dual(q0, P.spec) - P.EG:.4f}")

    def f(t, y):
        r = P.unpack(y); U, A, Bm, a, b = P.core(r); lam = (-(a + gamma) / b).real if abs(b) > 1e-14 else 0.0
        f.lam = lam; return P.pack(U @ (A + lam * Bm) @ U.conj().T)

    Tt = (q0 - 0.05) / gamma; ts = np.linspace(0, Tt, 2001); t0 = time.time()
    sol = solve_ivp(f, (0, Tt), P.pack(rho0), method='DOP853', rtol=1e-7, atol=1e-9, t_eval=ts)
    rows = []
    for k in range(len(ts)):
        r = P.unpack(sol.y[:, k]); f(ts[k], sol.y[:, k]); lam = f.lam
        U, A, Bm, a, b = P.core(r); rd = U @ (A + lam * Bm) @ U.conj().T; Y = rd - 1j * lam * (P.Q @ r - r @ P.Q)
        rows.append((ts[k], P.ex(r, P.Q).real, P.ex(r, P.N1).real, P.ex(r, P.H).real, -lam, kappa * np.linalg.norm(Y) ** 2,
                     abs(P.ex(r, P.X)), abs(P.ex(r, P.T1))))
    R = np.array(rows); t, q, N1, E, mu, diss, X, T1 = R.T
    print(f"  wall {time.time() - t0:.0f}s; energy balance: E0-E_end={E[0] - E[-1]:.4f} = L {trapz(diss, t):.4f} + R_Q {-trapz(mu * np.gradient(q, t), t):.4f}")
    print("  plateau means of mu (windows [n+0.1, n+0.4]):")
    for lo in np.arange(0, 2.5, 0.5):
        m = (q > lo + 0.1) & (q < lo + 0.4)
        if m.sum(): print(f"    q in [{lo + 0.1:.1f},{lo + 0.4:.1f}]: mu={mu[m].mean():.4f}  |<e^(i theta)>|={X[m].mean():.3f}  <N1>-q/2={np.mean(N1[m] - q[m] / 2):+.3f}")
    out = args.data / f'pair_leak_{gamma}_J{EJ}_b{beta}.npz'
    np.savez(out, R=R, EG=P.EG); print("  saved", out)
    print("  columns of R: t, <Q>, <N1>, E, mu, D (internal dissipation rate), |<e^(i theta)>|, |<T1>|")


# ============================================================================================ CLI
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--data', type=Path, default=DATA, help='output directory (default ../data)')
    sub = ap.add_subparsers(dest='mode', required=True)

    h = sub.add_parser('hull', help='T=0 hull and parity splitting'); h.add_argument('--M', type=int, default=7)
    h.add_argument('--EJ', type=float, nargs='+', default=[0.0, 0.1, 0.25, 0.5, 1.0, 2.0])

    d = sub.add_parser('duality', help='Gibbs-orbit staircase by duality'); d.add_argument('--beta', type=float, nargs='+', default=[1.0, 2.0, 4.0])
    d.add_argument('--EJ', type=float, nargs='+', default=[0.0, 0.5]); d.add_argument('--M', type=int, nargs='+', default=[4, 5])

    r = sub.add_parser('relax', help='fixed-charge relaxation'); r.add_argument('q0', type=float, help='total charge (integer: all on island 1; fractional: charged through a phase reference)')
    r.add_argument('--EJ', type=float, default=0.5); r.add_argument('--beta', type=float, default=2.0); r.add_argument('--M', type=int, default=5)
    r.add_argument('--T', type=float, default=300.0); r.add_argument('--Ex', type=float, default=0.3)

    l = sub.add_parser('leak', help='prescribed slow leak of the total charge'); l.add_argument('gamma', type=float, help='leak rate -d<Q>/dt')
    l.add_argument('--EJ', type=float, default=0.5); l.add_argument('--beta', type=float, default=2.0); l.add_argument('--M', type=int, default=4)
    l.add_argument('--q0', type=float, default=2.5); l.add_argument('--Ex', type=float, default=0.3)

    args = ap.parse_args(); args.data.mkdir(parents=True, exist_ok=True)
    {'hull': mode_hull, 'duality': mode_duality, 'relax': mode_relax, 'leak': mode_leak}[args.mode](args)


if __name__ == '__main__':
    main()
