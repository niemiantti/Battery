#!/usr/bin/env python3
"""
Recomputes the numerical diagnostics quoted in the paper from the saved runs in ../data:

  * two-unit recurrence of the dual staircase (cutoff check),
  * charge drift, spectral drift, stationarity residuals and clock-rate statistics of the fixed-charge relaxations,
  * energy balance, plateau means of the multiplier and dissipated fractions of the prescribed leaks.
"""
import argparse
from pathlib import Path
import numpy as np
from two_islands import Pair, Ec, DATA

DELTA_J = 0.2038   # parity splitting at E_J = Ec/2 (from staircase.py / two_islands.py hull)


def trapz(y, x): return np.sum(0.5 * (y[1:] + y[:-1]) * np.diff(x))


def recurrence(data):
    print("Two-unit recurrence |E_min(q+2) - E_min(q) - 2Ec(q+1)| (Lagrange duality, E_J = Ec/2):")
    qs = np.arange(0, 2.01, 0.25)
    for beta in (2.0, 4.0):
        for M in (4, 5):
            P = Pair(M, 0.5, beta); E = np.array([P.Emin_dual(q, P.spec) for q in qs]); E2 = np.array([P.Emin_dual(q + 2, P.spec) for q in qs])
            print(f"  beta*Ec={beta} |m_i|<={M}: {np.max(np.abs(E2 - E - 2 * Ec * (qs + 1))):.1e}")


def relaxations(data):
    for fn in sorted(data.glob('pair_relax_q*_J0.5_b*.npz')):
        R = np.load(fn); A = R['R']; t = A[:, 0].real; N1, N2, E, mu = A[:, 1].real, A[:, 2].real, A[:, 3].real, A[:, 4].real
        X, T1, Yn, comm, sdr = A[:, 5], A[:, 6], A[:, 8].real, A[:, 9].real, A[:, 10].real; EG, Emin = float(R['EG']), float(R['Emin'])
        q = N1 + N2
        print(f"\n{fn.name}:")
        print(f"  initial q={q[0]:.4f}, E-E_G={E[0]-EG:.4f}, E_min-E_G={Emin-EG:.4f} (W_free={E[0]-Emin:.4f}); final E-E_min={E[-1]-Emin:.4f}")
        print(f"  charge drift max|q(t)-q(0)|={np.max(np.abs(q - q[0])):.1e}; spectral drift max={np.max(sdr):.1e}; "
              f"||Y||(end)={Yn[-1]:.1e}; ||[K,rho]||(end)={comm[-1]:.1e}")
        om = np.gradient(np.unwrap(np.angle(X)), t); omT = np.gradient(np.unwrap(np.angle(T1)), t)
        print(f"  relative-phase rate at t=0: {om[0]:.3f} (ac Josephson 2Ec(N1-N2)={2 * Ec * (N1[0] - N2[0]):.3f}); "
              f"|<e^(i theta)>| end={abs(X[-1]):.4f}, arg={np.angle(X[-1]):+.3f}")
        if abs(q[0] - round(q[0])) > 1e-3:
            m = (t >= 60) & (t <= 300)
            print(f"  common-phase rate on t in [60,300]: mean {omT[m].mean():.4f}, half-range {(omT[m].max() - omT[m].min()) / 2:.4f}; "
                  f"mu(end)={mu[-1]:.4f}; plateau slope 3Ec-delta_J={3 * Ec - DELTA_J:.4f}; |<T1>|(end)={abs(T1[-1]):.3f}")


def leaks(data):
    for fn in sorted(data.glob('pair_leak_*_J0.5_b*.npz')):
        L = np.load(fn); A = L['R']; t, q, N1, E, mu, diss, Xa, T1a = A.T
        Ldiss = trapz(diss, t); RQ = -trapz(mu * np.gradient(q, t), t); rel = E[0] - E[-1]
        print(f"\n{fn.name}:")
        print(f"  energy balance: released {rel:.4f} = L {Ldiss:.4f} + R_Q {RQ:.4f}  (closure {rel - Ldiss - RQ:+.1e}); dissipated fraction L/released = {Ldiss / rel:.3f}")
        for lo, hi, ideal in ((2.2, 2.45, 3 * Ec - DELTA_J), (1.25, 1.45, Ec + DELTA_J), (0.75, 0.95, Ec - DELTA_J)):
            m = (q > lo) & (q < hi)
            if m.sum(): print(f"  mean mu on q in [{lo},{hi}]: {mu[m].mean():.4f}  (plateau value {ideal:.4f})")
        low = T1a < 0.02; edges = np.diff(low.astype(int)); starts = q[1:][edges == 1]; stops = q[1:][edges == -1]
        print("  windows with |<T1>| < 0.02 (q from, to):", [(round(float(a), 2), round(float(b), 2)) for a, b in zip(starts, stops)])


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--data', type=Path, default=DATA); args = ap.parse_args()
    recurrence(args.data); relaxations(args.data); leaks(args.data)
