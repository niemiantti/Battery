# Charge-locked ergotropy in a Josephson-coupled quantum battery

Code and data for the article *Charge-locked ergotropy in a Josephson-coupled quantum battery*
(A. J. Niemi) and its Supplemental Material. The scripts regenerate the figures that are made from
data and the numerical values quoted in the article and in the supplement.

The model is a pair of superconducting charge islands coupled by a Josephson junction,

    H = E_C (N_1^2 + N_2^2) - E_J cos(phi_1 - phi_2),        Q = N_1 + N_2 conserved,

with `E_C = (2e)^2 / (2 C_Sigma)`. Units are `hbar = E_C = 1`, so times are in `hbar/E_C`. Unless
stated otherwise `E_J = E_C/2` and the Gilbert parameter is `kappa = 1/2`. Equation numbers without
the prefix S refer to the article, those with it to the supplement.

## Layout

```
src/two_islands.py    model and covariant qLLG kernel; sub-commands hull | duality | relax | leak
src/spectrum.py       fixed-spectrum staircase E_min(P, q), exact from the level crossings
src/staircase.py      data of Fig. 1
src/diagnostics.py    numbers of Sec. S7 and Table S2, recomputed from the saved runs
src/circuit.py        numbers of Sec. S8
src/make_figures.py   Figs. 1 and 2
data/                 saved runs behind Figs. 1 and 2 and Table S2 (.npz)
data/extra/           additional runs and checks that the article does not use
figures/              output of make_figures.py
reports/              console output of spectrum.py, diagnostics.py, circuit.py and the hull sub-command
reproduce.sh          all commands in order
```

## Where each result comes from

| Result | Script | Output |
|---|---|---|
| Fig. 1 | `staircase.py`, `make_figures.py` | `data/pair_staircase.npz`, `figures/fig1.*` |
| Fig. 2 | `two_islands.py relax`, `two_islands.py leak`, `make_figures.py` | `data/pair_relax_*.npz`, `data/pair_leak_*.npz`, `figures/fig2.*` |
| Parity splitting, bounds (13), Table S1 and the plateau widths (Secs. S2-S4) | `spectrum.py` | `reports/spectrum.txt` |
| Relaxations, phase rates, finite-current offsets and Table S2 (Sec. S7) | `diagnostics.py` | `reports/diagnostics.txt` |
| Circuit numbers and the relations used in Sec. S8 | `circuit.py` | `reports/circuit.txt` |

The numbers in the text of the article come from the same reports: the widths 0.16 and 0.28 of the
pinned plateaus at beta E_C = 2 and 1 (Table S1, `spectrum.py`), the common-phase rate 2.79 E_C/hbar,
0.3% below (3 E_C - delta_J)/hbar = 2.796 E_C/hbar (`diagnostics.py`, `spectrum.py`), and the loss
fractions 8% and 16% (Table S2, `diagnostics.py`).

Fig. S1 is a circuit schematic and has no data.

## Requirements

Python >= 3.10 with numpy, scipy and matplotlib (`pip install -r requirements.txt`).

## Quick start

Everything below runs in seconds and uses the saved runs in `data/`.

```
cd src
python spectrum.py          # delta_J, Table S1, recurrence (11), bounds (13); Secs. S2-S4
python diagnostics.py       # Sec. S7 and Table S2
python circuit.py           # Sec. S8
python staircase.py         # writes data/pair_staircase.npz
python make_figures.py      # figures/fig1 and fig2 (.pdf and .png)
```

`./reproduce.sh` runs these in order and stores the console output in `reports/`.

## Dynamical runs

All runs use `E_J = E_C/2` and `kappa = 1/2`. The ladder is `|m_1|, |m_2| <= M`, the cutoff m_max of
the supplement. Times are wall times on one core.

| Command | Content | M | Time |
|---|---|---|---|
| `python two_islands.py relax 2 --beta 2` | fixed-charge relaxation of the one-sided boost, Fig. 2(a,b) | 5 | ~4 min |
| `python two_islands.py relax 2.5 --beta 2` | relaxation toward the moving minimum at q = 2.5, Fig. 2(b) | 5 | ~4 min |
| `python two_islands.py leak 0.00025 --beta 4` | prescribed-current discharge, Fig. 2(c,d), Table S2 | 4 | ~25 min |
| `python two_islands.py leak 0.00025 --beta 2` | the same at beta E_C = 2, Fig. 2(c), Table S2 | 4 | ~25 min |

`./reproduce.sh --runs` repeats these runs before the analysis. They write into `data/` and replace
the saved files; `python two_islands.py --data DIR ...` writes elsewhere.

## Preparation and integration

Every run starts from the one-sided boost `T_1^2 rho_G T_1^-2` of the Gibbs state (Sec. S7). This
state is block diagonal in the total charge and has zero charge mobility, so the covariant flow cannot
change its mean charge. The state at q = 2.5 is produced by the prescribed-rate flow,
`dq/dt = E_C/(150 hbar)`, while island 1 is coupled to an external phase reference,
`H -> H - E_x cos(phi_1)` with `E_x = 0.3 E_C`, Eq. (S31), until the target charge is reached at
`t = 75`. The contact is then removed. The discharge runs first relax this state at fixed charge for a
time 300 (`prepare()` in `two_islands.py`).

The flow is integrated with DOP853 (scipy) at relative and absolute tolerances `(1e-8, 1e-10)` for the
preparation and the fixed-charge relaxations and `(1e-7, 1e-9)` for the discharges. The multiplier is
set to zero when the mobility falls below the round-off threshold `1e-14`, or `1e-12` during the
charging stage.

## Reproducibility

The files in `data/` are the runs behind Figs. 1 and 2 and Table S2. This version of the code
regenerates their arrays bit for bit under Python 3.13, numpy 2.5.3 and scipy 1.18.1 on Linux x86-64
(checked for all four dynamical runs, with OpenBLAS on one thread). Bit-level agreement should not be
expected with other library builds, because two stages amplify round-off. The charging stage starts
from a state of zero charge mobility, where the multiplier is regularized by the round-off threshold;
a change of tolerance moves the prepared state at q = 2.5 in its fourth digit. The discharge passes
through windows in which the mobility collapses; between integrations with different step sequences
the released energy at beta E_C = 2 changes in its third decimal, while the loss fraction stays
between 0.158 and 0.162 (`data/extra`).

## Data format

In the code `lam` is the multiplier lambda of the article, `gamma` the discharge rate, `M` the ladder
cutoff and `Ex` the energy E_x of the contact to the phase reference.

`pair_relax_*.npz`: array `R` (complex) with columns
`t, <N1>, <N2>, E, lambda, <e^{i theta}>, <T1>, <T2>, ||Y||, ||[K,rho]||, spectral drift`,
plus `EG` (Gibbs energy) and `Emin` (constrained minimum at the initial charge, by duality on a grid).
Here `Y` is the covariant velocity of Eq. (S19) and `K = H - lambda Q`.

`pair_leak_*.npz`: array `R` (real) with columns
`t, <Q>, <N1>, E, lambda, D, |<e^{i theta}>|, |<T1>|`, where `D = kappa Tr(Y^2)` is the internal
dissipation rate of Eq. (8), plus `EG`; files written by the present `two_islands.py` also store the
tolerances `rtol`, `atol`. Files written with `--accumulate` carry two more columns, the
charge-transfer energy `R_Q` and the internal loss `L` of Sec. S7 integrated together with the state.

`pair_staircase.npz`: `q`, the curves `W_T0_J{EJ}` (pure spectrum) and `W_b{beta}_J{EJ}` (Gibbs
spectra) of the charge-locked ergotropy, and `EJs`, `dJ` for the parity splitting.

## Additional runs

`data/extra/` holds six runs that the article does not use: the fixed-charge relaxation of the
one-sided boost at beta E_C = 1; the two discharges of Table S2 repeated with `R_Q` and `L` integrated
together with the state, a check of the quadrature on the output grid (loss fractions 0.0805 and
0.1624, against 0.080 and 0.159 by quadrature); the one at beta E_C = 2 repeated with tolerances
tightened a hundredfold (0.1619); and discharges at beta E_C = 2 with the faster rates gamma = 5e-4
and 2e-3. `diagnostics.py` lists them in a separate section.

```
python two_islands.py --data ../data/extra relax 2 --beta 1
python two_islands.py --data ../data/extra leak 0.00025 --beta 4 --accumulate
python two_islands.py --data ../data/extra leak 0.00025 --beta 2 --accumulate
python two_islands.py --data ../data/extra leak 0.00025 --beta 2 --accumulate --rtol 1e-9 --atol 1e-11
python two_islands.py --data ../data/extra leak 0.0005 --beta 2
python two_islands.py --data ../data/extra leak 0.002 --beta 2
```

## License

MIT, see `LICENSE`.
