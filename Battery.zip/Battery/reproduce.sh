#!/bin/sh
# Regenerates the reports and figures from the saved runs in data/ (a few seconds).
# With --runs the four dynamical runs are repeated first; they replace the files in data/
# (E_J = E_C/2, kappa = 1/2; wall times on one core are listed in README.md, about an hour in total).
set -e
cd "$(dirname "$0")/src"
mkdir -p ../reports ../figures

report() {                       # report NAME COMMAND...: run COMMAND and keep its output in reports/NAME.txt
    name=$1
    shift
    "$@" > "../reports/$name.txt"
    cat "../reports/$name.txt"
}

if [ "$1" = "--runs" ]; then
    python3 two_islands.py relax 2   --beta 2                    # one-sided boost      -> data/pair_relax_q2.0_J0.5_b2.0.npz
    python3 two_islands.py relax 2.5 --beta 2                    # moving minimum       -> data/pair_relax_q2.5_J0.5_b2.0.npz
    python3 two_islands.py leak 0.00025 --beta 4                 # discharge            -> data/pair_leak_0.00025_J0.5_b4.0.npz
    python3 two_islands.py leak 0.00025 --beta 2                 #                      -> data/pair_leak_0.00025_J0.5_b2.0.npz
fi

report hull        python3 two_islands.py hull                   # T = 0 sector energies and delta_J for several E_J
report spectrum    python3 spectrum.py                           # Secs. S2-S4, Table S1
python3 staircase.py                                             # data of Fig. 1       -> data/pair_staircase.npz
report diagnostics python3 diagnostics.py                        # Sec. S7, Table S2
report circuit     python3 circuit.py                            # Sec. S8
python3 make_figures.py                                          # figures/fig1, fig2
