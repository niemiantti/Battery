#!/usr/bin/env python3
"""
Numbers of the outline of a circuit realization, Sec. S8 of the Supplemental Material, and checks of
the relations used there:

  A. energy scale: E_C/h for C_Sigma = 31.0 fF and the temperatures of beta*Ec = 4 and 2,
  B. Sequence I: gate work, heat and locked energy of the one-sided preparation,
  C. Sequence II: the overlap u = <g_3|T_1|g_2>, and the gap and pi/2 time at the crossing for Ex = 0.1 Ec,
  D. Sequence III: symmetry of the equilibrium charge q_eq(lam_g) and the work of the two gate strokes,
  E. device requirements: a mutual capacitance c = C_m/C_Sigma.

Unless noted, c = 0, E_J = E_C/2 and E_C/h = 2.50 GHz; the code uses hbar = E_C = 1.

    python circuit.py
"""
import numpy as np
from scipy import constants as sc

from spectrum import FixedSpectrum, parity_splitting, relative_hamiltonian
from two_islands import Ec, Pair, trapz

EJ = 0.5
F_EC = 2.50e9                      # E_C / h in Hz, the rounded value used in Sec. S8
W_EC = 2 * np.pi * F_EC            # E_C / hbar in 1/s
T_UNIT = 1 / W_EC                  # hbar / E_C in s
NREL = 9                           # cutoff of the relative-charge ladder


def ladder(parity, EJ=EJ, nrel=NREL, c=0.0):
    """Eigenvalues, eigenvectors and relative charges of the relative Hamiltonian of Eq. (10),
    for even (parity 0) or odd (parity 1) total charge, on |n| <= nrel (+1/2)."""
    h, n = relative_hamiltonian(parity, EJ, nrel + parity, c)       # n = -nrel..nrel, or -(nrel+1/2)..(nrel+1/2)
    e, v = np.linalg.eigh(h)
    return e, v, n


def q_equilibrium(lam, beta, EJ=EJ, Mmax=40):
    """Equilibrium charge q_eq(lam_g) of the pair in weak contact with the reservoir (Sec. S4)."""
    ze = np.sum(np.exp(-beta * ladder(0, EJ)[0]))
    zo = np.sum(np.exp(-beta * ladder(1, EJ)[0]))
    M = np.arange(-Mmax, Mmax + 1)
    z = np.where(M % 2 == 0, ze, zo)
    lam = np.atleast_1d(lam)
    x = -beta * 0.5 * Ec * M[None, :] ** 2 + beta * lam[:, None] * M[None, :]
    w = np.exp(x - x.max(axis=1, keepdims=True)) * z
    return (w @ M) / w.sum(axis=1)


def boost_energies(beta, c=0.0, M=6, EJ=EJ):
    """Energies, relative to E_G, of the one-sided boost rho_0 = T_1^2 rho_G T_1^-2 and of the balanced
    minimum rho_* = B rho_G B^+ for the pair with mutual capacitance c, on the ladder |m_i| <= M:
    returns E(rho_0) - E_G, E(rho_*) - E_G, the work Tr[rho_* (H_1 - H)] of the reverse edge to
    H_1 = T_1^2 H T_1^-2, and the energy Tr[(rho_* - rho_0) H_1] released by the second relaxation."""
    P = Pair(M, EJ, None)
    H = Ec * (0.5 * P.Q @ P.Q + 2 / (1 + 2 * c) * P.n @ P.n) - 0.5 * EJ * (P.X + P.X.conj().T)
    E, V = np.linalg.eigh(H)
    w = np.exp(-beta * (E - E.min()))
    w /= w.sum()
    rG = (V * w) @ V.conj().T
    EG = float(np.sum(w * E))
    T2 = P.T1 @ P.T1
    B = P.T1 @ P.T2
    r0 = T2 @ rG @ T2.conj().T
    rs = B @ rG @ B.conj().T
    H1 = T2 @ H @ T2.conj().T

    def ex(r, O):
        return float(np.trace(r @ O).real)
    return ex(r0, H) - EG, ex(rs, H) - EG, ex(rs, H1 - H), ex(rs, H1) - ex(r0, H1)


def main():
    dJ = parity_splitting(EJ)[0]

    print("A. Energy scale")
    CS = 31.0e-15
    fEC = (2 * sc.e) ** 2 / (2 * CS) / sc.h
    print(f"  C_Sigma = 31.0 fF: E_C/h = {fEC / 1e9:.4f} GHz (2.50 GHz used below); hbar/E_C = {T_UNIT * 1e12:.1f} ps; "
          f"E_C/k_B = {sc.h * F_EC / sc.k * 1e3:.0f} mK")
    print(f"  beta*Ec = 4 and 2 correspond to T = {sc.h * F_EC / sc.k / 4 * 1e3:.1f} and {sc.h * F_EC / sc.k / 2 * 1e3:.1f} mK")

    print("\nB. Sequence I: heat of a one-sided preparation (|m_i| <= 6)")
    for beta in (4.0, 2.0):
        e0, es, wrev, q2 = boost_energies(beta)
        print(f"  beta*Ec = {beta:g}: gate work of the sudden edge E(rho_0) - E_G = {e0:.6f} Ec; heat of the within-sector relaxation "
              f"E(rho_0) - E(rho_*) = {e0 - es:.6f} Ec; locked E(rho_*) - E_G = {es:.6f} Ec; reverse edge: work {wrev:+.1e} Ec, "
              f"then heat {q2:.6f} Ec")

    print("\nC. Sequence II: Ramsey measurement of intersector coherence")
    lam_star = 3 * Ec - dJ
    e0, v0, n0 = ladder(0)
    e1, v1, n1 = ladder(1)
    # T_1 raises Q by one and the relative charge n by 1/2: <g_3|T_1|g_2> = sum_n g_odd(n + 1/2) g_even(n)
    u = sum(v1[np.argmin(np.abs(n1 - (x + 0.5))), 0] * v0[i, 0] for i, x in enumerate(n0) if np.min(np.abs(n1 - (x + 0.5))) < 1e-9)
    print(f"  lam_* = s_2 = 3Ec - delta_J = {lam_star:.6f} Ec;  |u| = |<g_3|T_1|g_2>| = {abs(u):.6f}")
    Ex = 0.1
    for Mc in (6, 7):
        P = Pair(Mc, EJ, None)
        H, Q, C = P.H.real, P.Q.real, 0.5 * (P.T1 + P.T1.conj().T).real
        wv = np.linalg.eigvalsh(H - lam_star * Q - Ex * C)[:2]
        gap = wv[1] - wv[0]
        print(f"  Ex = {Ex} Ec, |m_i| <= {Mc}: gap at lam_g = lam_* {gap:.6f} Ec = h x {gap * F_EC / 1e6:.1f} MHz "
              f"(two-sector estimate Ex|u| = {Ex * abs(u):.6f} Ec); pi/2 time pi hbar/(2 gap) = {np.pi / (2 * gap) * T_UNIT * 1e9:.2f} ns")

    print("\nD. Sequence III: gate spectroscopy and work recovery, dW_g = (-q + lam_g/Ec) dlam_g")
    lam = np.linspace(0, 2, 20001)
    for beta in (4.0, 2.0):
        qe = q_equilibrium(lam, beta)
        sym = np.max(np.abs(qe[::-1] + qe - 2))                       # q_eq(2Ec - lam_g) = 2 - q_eq(lam_g)
        W_up = trapz(-2.0 + lam / Ec, lam)                             # contact open, q = 2: lam_g from 0 to 2Ec
        W_down = -trapz(-qe + lam / Ec, lam) + 0.0                     # charge exchange, q = q_eq(lam_g): 2Ec to 0
        print(f"  beta*Ec = {beta:g}: q_eq(0) = {qe[0]:+.1e}, q_eq(2Ec) = {qe[-1]:.6f}, max|q_eq(2Ec - lam_g) + q_eq(lam_g) - 2| = {sym:.1e}; "
              f"W_g(up) = {W_up:+.6f} Ec, W_g(down) = {W_down:+.1e} Ec; returned to the gate source {-(W_up + W_down):.6f} Ec")

    print("\nE. Device requirements: mutual capacitance c = C_m/C_Sigma = 0.05, relative charging term 2 Ec n^2/(1+2c)")
    c = 0.05
    q = np.linspace(0, 2, 2001)
    for beta in (4.0, 2.0):
        S = FixedSpectrum(EJ, beta, 8, c=c)
        f = S.WQ(q) - 0.5 * Ec * q ** 2
        upper = 0.5 * Ec * (1 - (q - 1) ** 2)
        rec = S.Emin(q + 2) - S.Emin(q) - 2 * Ec * (q + 1)
        e0 = boost_energies(beta, c)[0]
        print(f"  beta*Ec = {beta:g}: W_Q(P,2) = {S.WQ(2.0):.6f} Ec; recurrence (11) max|err| = {np.abs(rec).max():.1e}; "
              f"bounds (13): min(W_Q - q^2/2) = {f.min():+.1e}, max(W_Q - q^2/2 - upper) = {(f - upper).max():+.1e}")
        print(f"      one-sided boost adds {e0:.6f} Ec and locks W_Q(P,2): fraction {S.WQ(2.0) / e0:.6f}; (1+2c)/(2+2c) = {(1 + 2 * c) / (2 + 2 * c):.6f}")


if __name__ == '__main__':
    main()
