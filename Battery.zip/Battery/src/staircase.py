#!/usr/bin/env python3
"""
Data for Fig. 1 of the article: the charge-locked ergotropy W_Q(P, q) = E_min(P, q) - E(P) on a grid of q.

  * Gibbs spectra at beta*Ec = 1, 2, 4 on the ladder |m_i| <= 5, by Lagrange duality, Eq. (S14),
    on a grid of multipliers; pure spectrum (T = 0) from the exact sector ground energies; E_J = 0 and Ec/2.
  * The parity splitting delta_J(E_J), Eq. (14), with its expansion E_J/2 - 3 E_J^2/(16 Ec), Eq. (S9).

Writes ../data/pair_staircase.npz.  The exact branch endpoints, widths and slopes (Table S1) are
computed from the level crossings in spectrum.py.

    python staircase.py [--data DIR]
"""
import argparse
from pathlib import Path

import numpy as np

from two_islands import DATA, Ec, Pair


def dual_curve(P, qs, spec, lams):
    """E_min(P, q) for all q in qs; Phi_P(lam) is evaluated once on the grid of multipliers."""
    Phi = P.Phi_dual(spec, lams)
    return np.array([np.max(Phi + lams * q) for q in qs])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', type=Path, default=DATA)
    args = ap.parse_args()
    out = {}
    # --- parity splitting versus E_J (exact sectors, |m_i| <= 7)
    EJs = np.linspace(0, 3.0, 61)
    dJ = []
    for EJ in EJs:
        P = Pair(7, EJ, None)
        e0, e1 = P.sector_ground(0), P.sector_ground(1)
        dJ.append(0.5 * Ec - (e1 - e0 - 0.5 * Ec))
    out['EJs'] = EJs
    out['dJ'] = np.array(dJ)
    print("delta_J(E_J):  E_J   exact    E_J/2 - 3E_J^2/16")
    for e in (0.1, 0.25, 0.5, 1.0):
        k = np.argmin(np.abs(EJs - e))
        print(f"               {e:<5} {dJ[k]:.4f}   {e / 2 - 3 * e ** 2 / 16:.4f}")
    # --- staircases
    qs = np.linspace(0, 4, 801)
    lams = np.linspace(-1, 9, 40001)
    out['q'] = qs
    for EJ in (0.0, 0.5):
        P0 = Pair(6, EJ, None)
        Qv = np.arange(-6, 13)
        E0 = np.array([P0.sector_ground(Q) for Q in Qv])
        hull = np.min(E0[None, :] - lams[:, None] * Qv[None, :], axis=1)        # Phi_P for the pure spectrum
        W0 = np.array([np.max(hull + lams * q) for q in qs]) - E0.min()
        out[f'W_T0_J{EJ}'] = W0
        for beta in (1.0, 2.0, 4.0):
            P = Pair(5, EJ, beta)
            W = dual_curve(P, qs, P.spec, lams) - P.EG
            out[f'W_b{beta}_J{EJ}'] = W
            print(f"E_J={EJ} beta*Ec={beta}: W_Q(1)={W[200]:.4f} W_Q(2)={W[400]:.4f} W_Q(3)={W[600]:.4f} W_Q(4)={W[800]:.4f}   "
                  f"recurrence |W(q+2)-W(q)-2Ec(q+1)|max = {np.max(np.abs(W[400:] - W[:401] - 2 * Ec * (qs[:401] + 1))):.1e}")
        print(f"E_J={EJ} T=0:        W_Q(1)={W0[200]:.4f} W_Q(2)={W0[400]:.4f} W_Q(3)={W0[600]:.4f}")
    np.savez(args.data / 'pair_staircase.npz', **out)
    print("saved", args.data / 'pair_staircase.npz')


if __name__ == '__main__':
    main()
