#!/usr/bin/env python3
"""
Fixed-spectrum staircase of the two-island pair, computed exactly from the level crossings
(Supplemental Material, Secs. S2-S4).

For a spectrum P = {p_1 >= p_2 >= ...} the minimum energy at prescribed mean charge q is

    E_min(P, q) = sup_lam [ Phi_P(lam) + lam q ],      Phi_P(lam) = sum_r p_r eta_(r)(lam),        (S13), (S14)

where eta_(1) <= eta_(2) <= ... are the levels E_j - lam m_j of H - lam Q.  The passive assignment
changes only where two levels of different total charge cross, at lam = (E_k - E_j)/(m_k - m_j).
Between two consecutive crossing values it is fixed and gives one vertex (q, E) of the convex,
piecewise-linear curve E_min(P, q); a crossing at lam* joins two vertices by a branch of slope lam*
and of width (p_r - p_r+1)(m_k - m_j) summed over the pairs that cross there, Eq. (S16).

The levels are obtained by diagonalizing Eq. (10) in every total-charge sector on the island
ladder |m_1|, |m_2| <= Nmax, the m_max of the supplement (hbar = E_C = 1).

Run as a script to print Table S1 and the checks of Secs. S2-S4:

    python spectrum.py
"""
import numpy as np

Ec = 1.0


def relative_hamiltonian(M, EJ, Nmax, c=0.0):
    """Relative-charge Hamiltonian of Eq. (10) without the constant Ec M^2/2, on the ladder allowed by
    |N_1|, |N_2| <= Nmax:  2 Ec n^2/(1+2c) - (EJ/2)(T + T^+),  n = (N_1 - N_2)/2 in Z + M/2.
    c = C_m/C_Sigma is the mutual capacitance of Sec. S8 (device requirements); c = 0 in the article."""
    nmax = Nmax - abs(M) / 2
    n = np.arange(-nmax, nmax + 0.5, 1.0)
    h = np.diag(2 * Ec * n ** 2 / (1 + 2 * c)) - 0.5 * EJ * (np.eye(len(n), k=1) + np.eye(len(n), k=-1))
    return h, n


def levels(EJ, Nmax, c=0.0):
    """All levels (E_j, m_j) of H on the ladder, sector by sector."""
    E, m = [], []
    for M in range(-2 * Nmax, 2 * Nmax + 1):
        h, n = relative_hamiltonian(M, EJ, Nmax, c)
        e = np.linalg.eigvalsh(h)
        E.extend(0.5 * Ec * M * M + e)
        m.extend([M] * len(e))
    return np.array(E), np.array(m, dtype=float)


def parity_splitting(EJ, Nmax=10, c=0.0):
    """delta_J of Eq. (14) and the ground energies of the even and odd relative ladders."""
    e_even = np.linalg.eigvalsh(relative_hamiltonian(0, EJ, Nmax, c)[0])[0]
    e_odd = np.linalg.eigvalsh(relative_hamiltonian(1, EJ, Nmax, c)[0])[0]
    return 0.5 * Ec - (e_odd - e_even), e_even, e_odd


class FixedSpectrum:
    """E_min(P, q) for the Gibbs spectrum at inverse temperature beta (beta=None: pure spectrum).
    c is the mutual capacitance of relative_hamiltonian(); c = 0 in the article."""

    def __init__(self, EJ=0.5, beta=None, Nmax=8, lam_range=(-0.95, 6.95), c=0.0):
        self.EJ, self.beta, self.Nmax, self.c = EJ, beta, Nmax, c
        self.E, self.m = levels(EJ, Nmax, c)
        if beta is None:
            self.p = np.zeros(len(self.E))
            self.p[0] = 1.0
            self.EG = self.E.min()
        else:
            w = np.exp(-beta * (self.E - self.E.min()))
            self.p = np.sort(w / w.sum())[::-1]                    # p_1 >= p_2 >= ...
            self.EG = float(np.sum(w * self.E) / w.sum())           # Gibbs energy = passive energy E(P)
        self._vertices(*lam_range)

    # --- passive assignment at fixed multiplier --------------------------------------------------
    def passive(self, lam):
        """Phi_P(lam), and the charge and energy of the passive state of H - lam Q, Eq. (S13)."""
        eta = self.E - lam * self.m
        order = np.argsort(eta, kind='stable')
        return float(self.p @ eta[order]), float(self.p @ self.m[order]), float(self.p @ self.E[order])

    def qP(self, lam):
        """Fixed-spectrum staircase q_P(lam) = -d Phi_P / d lam (Sec. S4), away from crossings."""
        return self.passive(lam)[1]

    # --- vertices and branches -------------------------------------------------------------------
    def _vertices(self, lo, hi):
        dm = self.m[:, None] - self.m[None, :]
        dE = self.E[:, None] - self.E[None, :]
        mask = dm > 0
        lam = dE[mask] / dm[mask]
        lam = np.unique(np.round(lam[(lam > lo) & (lam < hi)], 12))
        mid = np.concatenate([[0.5 * (lo + lam[0])], 0.5 * (lam[1:] + lam[:-1]), [0.5 * (lam[-1] + hi)]])
        v = np.array([self.passive(x)[1:] for x in mid])
        keep = np.concatenate([[True], np.abs(np.diff(v[:, 0])) > 1e-13])   # crossings that open no branch
        self.qv, self.Ev = v[keep, 0], v[keep, 1]
        self.slopes = np.diff(self.Ev) / np.diff(self.qv)              # multiplier on each branch
        self.crossings = lam

    def Emin(self, q):
        """E_min(P, q), exact on the range of charges covered by the vertices."""
        return np.interp(q, self.qv, self.Ev)

    def WQ(self, q):
        """Charge-locked ergotropy W_Q(P, q) = E_min(P, q) - E(P), Eq. (2)."""
        return self.Emin(q) - self.EG

    def slope(self, q):
        """lam(q) = d E_min / d q on the branch that contains q."""
        i = np.clip(np.searchsorted(self.qv, q, side='right') - 1, 0, len(self.slopes) - 1)
        return self.slopes[i]

    def branch(self, lam_star, tol=1e-9):
        """Charge interval (q-, q+) of the branch with slope lam_star; (None, None) if no branch opens."""
        i = np.argmin(np.abs(self.slopes - lam_star))
        if abs(self.slopes[i] - lam_star) > tol:
            return None, None
        return self.qv[i], self.qv[i + 1]

    def branches(self, q_lo, q_hi, min_width=0.0):
        """List of (q-, q+, slope) for the branches inside [q_lo, q_hi]."""
        return [(self.qv[i], self.qv[i + 1], self.slopes[i]) for i in range(len(self.slopes))
                if self.qv[i + 1] > q_lo and self.qv[i] < q_hi and self.qv[i + 1] - self.qv[i] > min_width]

    def jumps(self, lam, eps=1e-7, tol=1e-9):
        """Contributions of the degenerate levels of H - lam Q to the jump of q_P at lam, Eq. (S16).
        Returns (first rank, last rank, charges, contribution) for every group of degenerate levels with
        different charges; ranks are counted from 1 in the passive ordering."""
        eta = self.E - lam * self.m
        order = np.argsort(eta, kind='stable')
        below = np.argsort(self.E - (lam - eps) * self.m, kind='stable')
        above = np.argsort(self.E - (lam + eps) * self.m, kind='stable')
        out, r = [], 0
        while r < len(order):
            s = r
            while s + 1 < len(order) and eta[order[s + 1]] - eta[order[r]] < tol:
                s += 1
            charges = sorted({int(x) for x in self.m[order[r:s + 1]]}, reverse=True)
            if len(charges) > 1:
                d = float(np.sum(self.p[r:s + 1] * (self.m[above[r:s + 1]] - self.m[below[r:s + 1]])))
                out.append((r + 1, s + 1, charges, d))
            r = s + 1
        return out


def gibbs_lower_bound(q, beta, EJ=0.5, Nmax=10, Mmax=60):
    """beta^-1 ln[Z(0)/Z(q/2)] of Eq. (S6): the Gibbs variational bound on W_Q(P,q) - Ec q^2/2."""
    ze = np.sum(np.exp(-beta * np.linalg.eigvalsh(relative_hamiltonian(0, EJ, Nmax)[0])))
    zo = np.sum(np.exp(-beta * np.linalg.eigvalsh(relative_hamiltonian(1, EJ, Nmax)[0])))
    M = np.arange(-Mmax, Mmax + 1)
    z = np.where(M % 2 == 0, ze, zo)

    def Z(x):
        return np.sum(np.exp(-beta * 0.5 * Ec * (M - 2 * x) ** 2) * z)
    return np.array([np.log(Z(0.0) / Z(x / 2)) / beta for x in np.atleast_1d(q)])


def table_S1(EJ=0.5, Nmax=8):
    """Rows of Table S1: principal interval, its width p_1 - p_2, pinned width at lam = Ec, W_Q(P, 1/2)."""
    dJ = parity_splitting(EJ, Nmax)[0]
    rows = []
    for beta in (None, 4.0, 2.0, 1.0):
        S = FixedSpectrum(EJ, beta, Nmax)
        qm, qp = S.branch(Ec - dJ)
        pm, pp = S.branch(Ec)
        pin = 0.0 if pm is None else pp - pm
        rows.append((beta, qm, qp, qp - qm, pin, float(S.WQ(0.5)), S))
    return rows


def main():
    EJ = 0.5
    print("Parity splitting, Eq. (14), at E_J = E_C/2 [Secs. S3 and S4]")
    for Nmax in (8, 10):
        dJ, ee, eo = parity_splitting(EJ, Nmax)
        print(f"  m_max = {Nmax:2d}: delta_J/Ec = {dJ:.6f}   s_0/Ec = 1 - delta_J = {1 - dJ:.6f}   s_2/Ec = 3 - delta_J = {3 - dJ:.6f}")
    print("  weak coupling, Eq. (S9):    E_J    delta_J (exact)   E_J/2 - 3E_J^2/16")
    for ej in (0.05, 0.1, 0.25, 0.5):
        print(f"                             {ej:<5}  {parity_splitting(ej)[0]:.6f}          {ej / 2 - 3 * ej ** 2 / 16:.6f}")
    ejs = np.logspace(-3, 1.5, 46)
    d = np.array([parity_splitting(e, 40)[0] for e in ejs])
    print(f"  bounds (S8) on E_J/Ec in [1e-3, 31.6]: min delta_J = {d.min():.2e} > 0, max 1/2 - delta_J = {np.max(0.5 - d):.3f}, "
          f"min 1/2 - delta_J = {np.min(0.5 - d):.2e} > 0")

    for Nmax in (8, 10):
        print(f"\nTable S1 (E_J = E_C/2, charge states |m_i| <= m_max = {Nmax})")
        print("  beta*Ec   principal interval      dq_pr     dq_pin    W_Q(P,1/2)/Ec")
        rows = table_S1(EJ, Nmax)
        for beta, qm, qp, w, pin, WQ, S in rows:
            b = 'inf' if beta is None else f'{beta:g}'
            print(f"  {b:>5}     [{qm:.4f}, {qp:.4f}]     {w:.4f}    {pin:.4f}    {WQ:.4f}")
    rows = table_S1(EJ, 10)

    print("\nChecks on the exact curves (m_max = 10) [Sec. S2]")
    q = np.linspace(0, 2, 2001)
    for beta, qm, qp, w, pin, WQ, S in rows:
        b = 'inf' if beta is None else f'{beta:g}'
        f = S.WQ(q) - 0.5 * Ec * q ** 2
        upper = 0.5 * Ec * (1 - (q - 1) ** 2)
        rec = S.Emin(q + 2) - S.Emin(q) - 2 * Ec * (q + 1)
        line = (f"  beta*Ec={b:>3}: W_Q(P,2)/Ec = {S.WQ(2.0):.10f}, W_Q(P,4)/Ec = {S.WQ(4.0):.10f}; recurrence (11) max|err| = {np.abs(rec).max():.1e}; "
                f"bounds (13): min(W_Q - q^2/2) = {f.min():+.1e}, max(W_Q - q^2/2 - upper) = {(f - upper).max():+.1e}")
        if beta is not None:
            lb = gibbs_lower_bound(q, beta, EJ)
            line += f"; Eq. (S6): min(W_Q - q^2/2 - bound) = {(f - lb).min():+.1e}"
        print(line)

    print("\nPrincipal and pinned plateaus (m_max = 10) [Sec. S4]")
    dJ = parity_splitting(EJ)[0]
    for beta, qm, qp, w, pin, WQ, S in rows[1:]:
        p = S.p
        print(f"  beta*Ec={beta:g}: p_1 = {p[0]:.6f}, p_2 = p_3 = {p[1]:.6f} (p_2 - p_3 = {p[1] - p[2]:.0e}), "
              f"p_1[1 - exp(-beta(Ec - delta_J))] = {p[0] * (1 - np.exp(-beta * (Ec - dJ))):.4f}")
        parts = [(r1, r2, ch, x) for r1, r2, ch, x in S.jumps(Ec) if r1 <= 3 or abs(x) > 5e-5]
        print("      jump of q_P at lam = Ec by degenerate pair of levels: "
              + "; ".join(f"ranks {r1}-{r2} (Q = {', '.join(map(str, ch))}): {x:.4f}" for r1, r2, ch, x in parts)
              + f"; total {sum(x for *_, x in S.jumps(Ec)):.4f} = pinned width {pin:.4f}")
    S = rows[1][-1]
    print("  beta*Ec=4, branches wider than 0.02 on 0 <= q <= 2:  " +
          "; ".join(f"[{a:.4f},{b:.4f}] {s:.4f}" for a, b, s in S.branches(0, 2, 0.02)))
    S = rows[2][-1]
    print("  beta*Ec=2, branches wider than 0.02 on 0 <= q <= 2:  " +
          "; ".join(f"[{a:.4f},{b:.4f}] {s:.4f}" for a, b, s in S.branches(0, 2, 0.02)))


if __name__ == '__main__':
    main()
