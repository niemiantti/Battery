#!/usr/bin/env python3
"""
Figures of the article from the saved data in ../data:

    fig1.{pdf,png}    Fig. 1   spectral structure of the pair          (pair_staircase.npz)
    fig2.{pdf,png}    Fig. 2   covariant qLLG dynamics                 (pair_relax_*.npz, pair_leak_*.npz)

Fig. S1 of the Supplemental Material is a circuit schematic and has no data.  The figures use the Inter
typeface when it is installed, and the default sans-serif font otherwise.

    python make_figures.py [--data DIR] [--figures DIR]
"""
import argparse
import logging
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from spectrum import parity_splitting

logging.getLogger('fontTools').setLevel(logging.ERROR)
ROOT = Path(__file__).resolve().parents[1]
Ec = 1.0
DELTA_J = parity_splitting(0.5)[0]
BLUE, ORANGE, GREEN, YELLOW, PURPLE, RED = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#6250d6', '#e34948'
EC = r'\mathcal{E}_{\rm C}'

SANS = {'font.family': 'sans-serif', 'font.sans-serif': ['Inter', 'Helvetica', 'Arial', 'DejaVu Sans'], 'mathtext.fontset': 'cm',
        'font.size': 7.5, 'axes.labelsize': 7.5, 'axes.titlesize': 7.5, 'legend.fontsize': 6.2, 'xtick.labelsize': 7, 'ytick.labelsize': 7,
        'lines.linewidth': 1.1, 'axes.linewidth': 0.5, 'xtick.major.width': 0.5, 'ytick.major.width': 0.5, 'pdf.fonttype': 42}


def save(fig, figures, name):
    fig.savefig(figures / f'{name}.pdf', metadata={'CreationDate': None})      # no time stamp: reruns give identical files
    fig.savefig(figures / f'{name}.png', dpi=300)
    plt.close(fig)
    print(figures / f'{name}.pdf', 'written')


def cum(y, x):
    return np.concatenate([[0.0], np.cumsum(0.5 * (y[1:] + y[:-1]) * np.diff(x))])


# ------------------------------------------------------------------------------------------- Fig. 1
def fig1(data, figures):
    D = np.load(data / 'pair_staircase.npz')
    q = D['q']
    with plt.rc_context(SANS):
        fig, ax = plt.subplots(1, 2, figsize=(4.2, 2.2))
        curves = [('W_T0_J0.5', r'$T=0$', BLUE), ('W_b4.0_J0.5', rf'$\beta{EC}=4$', PURPLE),
                  ('W_b2.0_J0.5', rf'$\beta{EC}=2$', GREEN), ('W_b1.0_J0.5', rf'$\beta{EC}=1$', RED)]
        a = ax[0]
        for key, lab, c in curves:
            a.plot(q, D[key] - Ec * q ** 2 / 2, color=c, label=lab)
        a.plot(q, D['W_T0_J0.0'] - Ec * q ** 2 / 2, color='k', ls=':', lw=1.0, label=r'$T=0,\ E_J=0$')   # upper bound (13)
        a.axhline(0, color='k', lw=0.5)                                                                  # lower bound (13)
        a.set_xlim(-0.15, 4.2)
        a.set_ylim(-0.01, 0.78)
        a.set_xticks(range(5))
        a.set_yticks([0, 0.2, 0.4, 0.6])
        a.set_xlabel(r'total charge $q$')
        a.set_ylabel(rf'$[\mathcal{{W}}_Q(q)-{EC}q^2/2]/{EC}$')
        a.set_title(rf'(a) locked ergotropy, $E_J={EC}/2$', loc='left')
        a.legend(frameon=False, handlelength=1.4, ncol=2, columnspacing=0.8, loc='upper left', fontsize=6.0,
                 borderaxespad=0.1, labelspacing=0.3)

        b = ax[1]
        for key, lab, c in (curves[0], curves[2], curves[3]):
            b.plot(q, np.gradient(D[key], q), color=c, lw=0.9, label=lab)
        b.plot(q, Ec * q, 'k--', lw=0.8, label=rf'${EC}\,q$')
        for k in range(2):
            b.hlines(Ec * (2 * k + 1) - DELTA_J, 2 * k, 2 * k + 1, colors='k', linestyles=':', lw=1.0)      # Eq. (15)
            b.hlines(Ec * (2 * k + 1) + DELTA_J, 2 * k + 1, 2 * k + 2, colors='k', linestyles=':', lw=1.0)
            b.hlines(Ec * (2 * k + 1), 2 * k + 0.5, 2 * k + 1.5, colors='0.5', lw=0.8)                       # pinned plateaus
        b.set_xlim(0, 4.05)
        b.set_ylim(0, 4.1)
        b.set_xticks(range(5))
        b.set_yticks(range(5))
        b.set_xlabel(r'total charge $q$')
        b.set_ylabel(rf'$\lambda=\partial\mathcal{{W}}_Q/\partial q$  $({EC})$')
        b.set_title('(b) frequency plateaus', loc='left')
        b.legend(frameon=False, handlelength=1.4, loc='upper left', fontsize=6.0, borderaxespad=0.1, labelspacing=0.3)
        ins = b.inset_axes([0.56, 0.09, 0.44, 0.44])
        for key, lab, c in (curves[0], curves[2], curves[3]):
            ins.plot(q, np.gradient(D[key], q), color=c, lw=0.9)
        ins.plot(q, Ec * q, 'k--', lw=0.8)
        ins.hlines([Ec - DELTA_J, Ec + DELTA_J], [0.6, 1.0], [1.0, 1.4], colors='k', linestyles=':', lw=1.0)
        ins.axhline(Ec, color='0.5', lw=0.8)
        ins.set_xlim(0.6, 1.4)
        ins.set_ylim(0.72, 1.3)
        ins.set_xticks([0.6, 1.0, 1.4])
        ins.set_yticks([0.9, 1.1])
        ins.tick_params(labelsize=5.5, length=2, pad=1.5)
        ins.tick_params(axis='y', direction='in', pad=-13)
        b.indicate_inset_zoom(ins, edgecolor='0.6', lw=0.6, alpha=1.0)
        for a in ax:
            a.spines[['top', 'right']].set_visible(False)
        fig.tight_layout(w_pad=0.8, pad=0.3)
        save(fig, figures, 'fig1')


# ------------------------------------------------------------------------------------------- Fig. 2
def fig2(data, figures):
    with plt.rc_context(SANS):
        fig, ax = plt.subplots(1, 4, figsize=(9.7, 2.5))
        # (a), (b): fixed-charge relaxations at beta*Ec = 2
        R = np.load(data / 'pair_relax_q2.0_J0.5_b2.0.npz')
        A = R['R']
        t, N1, N2, E, X = A[:, 0].real, A[:, 1].real, A[:, 2].real, A[:, 3].real, A[:, 5]
        Emin = float(R['Emin'])
        ax[0].plot(t, N1 - N2, color=BLUE, label=r'$\Delta N=\langle N_1\rangle-\langle N_2\rangle$')
        ax[0].plot(t, 4 * X.imag, color=ORANGE, lw=0.8, label=r'$4\langle\sin\theta\rangle$')
        ax[0].plot(t, E - Emin, color=GREEN, label=rf'$(E-E_{{\min}})/{EC}$')
        ax[0].set_xlim(0, 100)
        ax[0].set_ylim(-1.15, 2.15)
        ax[0].set_xticks([0, 25, 50, 75, 100])
        ax[0].set_yticks([-1, 0, 1, 2])
        ax[0].set_xlabel(rf'$t\,{EC}/\hbar$')
        ax[0].legend(frameon=False, handlelength=1.3, loc='upper right')
        om = np.gradient(np.unwrap(np.angle(X)), t)
        ax[1].plot(t, om, color=ORANGE, lw=0.8, label=r'$\dot{\arg}\langle e^{i\theta}\rangle$')
        ax[1].plot(t, 2 * Ec * (N1 - N2), color=BLUE, ls='--', lw=0.8, label=rf'$2{EC}\Delta N/\hbar$')
        R = np.load(data / 'pair_relax_q2.5_J0.5_b2.0.npz')
        A = R['R']
        t, T1, lam = A[:, 0].real, A[:, 6], A[:, 4].real
        ax[1].plot(t, np.gradient(np.unwrap(np.angle(T1)), t), color=GREEN, lw=0.8, label=r'$\dot{\arg}\langle T_1\rangle$')
        ax[1].plot(t, lam, color='k', ls=':', lw=0.9, label=r'$\lambda(t)/\hbar$')
        ax[1].set_xlim(0, 100)
        ax[1].set_xticks([0, 25, 50, 75, 100])
        ax[1].set_ylim(-0.6, 4.8)
        ax[1].set_yticks([0, 2, 4])
        ax[1].set_xlabel(rf'$t\,{EC}/\hbar$')
        ax[1].set_ylabel(rf'frequency $({EC}/\hbar)$')
        ax[1].legend(frameon=False, handlelength=1.3, loc='center right', bbox_to_anchor=(1.0, 0.46), ncol=2, columnspacing=0.8)
        # (c), (d): prescribed-current discharges
        for level, qa, qb in ((Ec - DELTA_J, 0, 1), (Ec + DELTA_J, 1, 2), (3 * Ec - DELTA_J, 2, 2.6)):    # plateaus of Eq. (15)
            ax[2].hlines(level, qa, qb, colors='0.78', lw=4.0, zorder=0)
        ax[2].text(0.03, Ec - DELTA_J + 0.22, rf'${EC}-\delta_J$', fontsize=6, color='0.35')
        ax[2].text(1.17, Ec + DELTA_J - 0.47, rf'${EC}+\delta_J$', fontsize=6, color='0.35')
        ax[2].text(1.97, 3 * Ec - DELTA_J + 0.27, rf'$3{EC}-\delta_J$', fontsize=6, color='0.35')
        for beta, c, lw in ((4.0, BLUE, 1.3), (2.0, ORANGE, 0.7)):
            L = np.load(data / f'pair_leak_0.00025_J0.5_b{beta}.npz')
            t, q, N1, E, lam, diss = L['R'].T[:6]
            ax[2].plot(q, lam, color=c, lw=lw, label=rf'$\beta{EC}={beta:g}$')
            if beta == 4.0:
                gamma = (q[0] - q[-1]) / (t[-1] - t[0])
                ax[3].plot(q, E[0] - E, color=BLUE, label='released')
                ax[3].plot(q, gamma * cum(lam, t), color=GREEN, ls=':', lw=1.5, label=r'$R_Q(t)$')
                ax[3].plot(q, cum(diss, t), color=YELLOW, label=r'$L(t)$')
        qs = np.linspace(0, 2.6, 50)
        ax[2].plot(qs, Ec * qs, color=GREEN, ls='--', lw=1.0, label=rf'${EC}q$')
        ax[2].set_xlim(0, 2.6)
        ax[2].set_ylim(0, 3.6)
        ax[2].set_xticks([0, 1, 2])
        ax[2].set_yticks([0, 1, 2, 3])
        ax[2].set_xlabel(r'$q(t)$')
        ax[2].set_ylabel(rf'$\lambda$  $({EC})$')
        ax[2].legend(frameon=False, handlelength=1.5, loc='upper left')
        ax[3].set_xlim(2.6, 0)
        ax[3].set_ylim(0, 4.6)
        ax[3].set_xticks([2, 1, 0])
        ax[3].set_yticks([0, 1, 2, 3, 4])
        ax[3].set_xlabel(r'$q(t)$')
        ax[3].set_ylabel(rf'energy $({EC})$')
        ax[3].legend(frameon=False, handlelength=2.0, loc='upper left', title=rf'$\beta{EC}=4$', title_fontsize=6.2, alignment='left')
        for a, lab in zip(ax, 'abcd'):
            a.set_title(f'({lab})', loc='left')
        fig.tight_layout(w_pad=0.6, pad=0.3)
        save(fig, figures, 'fig2')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', type=Path, default=ROOT / 'data')
    ap.add_argument('--figures', type=Path, default=ROOT / 'figures')
    ap.add_argument('--only', nargs='+', choices=['fig1', 'fig2'], default=['fig1', 'fig2'])
    args = ap.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    for name in args.only:
        {'fig1': fig1, 'fig2': fig2}[name](args.data, args.figures)


if __name__ == '__main__':
    main()
